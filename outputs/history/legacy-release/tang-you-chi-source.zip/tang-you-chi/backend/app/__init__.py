"""Local tourism journal API."""
